﻿
----------------------------------------
-- DEFAULT KEY TO TOGGLE AMP PANEL
----------------------------------------

KEY = "F7" -- change this value only

bindKey(KEY, "down", onMainWindow)
setTimer(outputChatBox,3000,1,"Press '"..KEY.."' to open your AMP panel")

----------------------------------------
-- END
----------------------------------------