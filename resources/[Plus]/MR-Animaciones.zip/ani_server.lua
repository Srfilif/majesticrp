addEvent("AnimationSet",true)
addEventHandler("AnimationSet",getRootElement(), 
	function (block, ani, loop)
		if(source)then
			if getElementData (source, "proteccion") ~= "arrestado" then
				if getElementData (source, "Ocupacion") ~= "Prostituta - On" then
					if getElementData (source, "follando") ~= "si" then
						if not isPedInVehicle (source) then
							if(block)then
								if loop then
									setPedAnimation(source,block,ani,-1,true, true, false)--loop)
								else
									setPedAnimation(source,block,ani,1,false, true, false)
								end
							else
								setPedAnimation(source)
							end
						else
							call(getResourceFromName("guitext"),"outputServerGuiText",source,"En este Momento No puedes Usar Animaciones",255,0,0)
						end
					else
						call(getResourceFromName("guitext"),"outputServerGuiText",source,"En este Momento No puedes Usar Animaciones",255,0,0)
					end
				else
					call(getResourceFromName("guitext"),"outputServerGuiText",source,"En este Momento No puedes Usar Animaciones",255,0,0)
				end
			else
				call(getResourceFromName("guitext"),"outputServerGuiText",source,"En este Momento No puedes Usar Animaciones",255,0,0)
			end
		end
	end)
	
addCommandHandler("anim",
	function (gracz, block, ani)
		if(block and ani)then
			triggerEvent("AnimationSet",gracz, tostring(block),tostring(ani), true)
		else
			triggerEvent("AnimationSet",gracz)
		end
	end)