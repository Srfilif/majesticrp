--mainTable = categories

menuLogo = "logo"
menuColor = "160,160,160"
viewedImage = "ttile"

items = {
	['fshop'] = {
		{ "100 Seeds", 500, 100},
		{ "200 Seeds", 1000, 200},
		{ "400 Seeds", 2000, 400},
		{ "600 Seeds", 3000, 600},
		{ "800 Seeds", 4000, 800},
		{ "1000 Seeds", 5000, 1000},
		{ "2000 Seeds", 10000, 2000},
	},
}

categories = {}

shops = {
	{ 1096.4423828125, -310.5849609375, 73.992187-1, "fshop", "0;0"},
}

trans = {
	["fshop"] = 0,
}

tcolor = {
	["fshop"] = "142,229,146",

}
