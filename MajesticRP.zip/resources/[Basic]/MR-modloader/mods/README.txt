You can place your mod files in this directory or use any other folder structure of your liking.

Don't forget to list the files in the resource's meta.xml.