--[[
	Author: https://github.com/Fernando-A-Rocha

	testing_client.lua

--]]

setDevelopmentMode(true)