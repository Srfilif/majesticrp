taxiModels = {[420]=true, [0]=true} 
defaultfare = 7
syncInterval = 20000
minFare, maxFare = 4, 5