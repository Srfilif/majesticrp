pickups_infos = {
	{ info = "/licencias", -2032.7227783203, -117.40300750732, 1035.171875, int = 3, dim = 0, r = 0, g = 255, b = 0, font = "default-bold"  },
}