local LicenciaArmas = {
{1562.1103515625, -1676.1279296875, 16.1953125, int = 0, dim = 0},
}

function getLicenciaArmas()
	return LicenciaArmas
end