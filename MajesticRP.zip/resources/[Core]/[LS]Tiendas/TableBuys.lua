buysshop = {
	["24/7"] = {
		{-27.940196990967, -89.615165710449, 1003.546875, int= 18, dim = 0, items={"Telefono", "Agenda", "Cuchillo de Caza (Arma)", "Lata de Spray", "Caja de Cigarros", "Encendedor", "Cámara", "Cerveza", "Agua"}},
	},
	["Bebidas"] = {
		{-2654.0190429688, 1413.6501464844, 906.27709960938, int= 3, dim = 0, items={"Cerveza", "Agua", "Caja de Cigarros", "Encendedor"}},
	},
	["Burger"] = {
		{377.26641845703, -67.437118530273, 1001.5078125, int= 10, dim = 3, items={"Hamburguesa", "Hamburguesa Chica", "Hamburguesa Grande"}},
		{377.26641845703, -67.437118530273, 1001.5078125, int= 10, dim = 2, items={"Hamburguesa", "Hamburguesa Chica", "Hamburguesa Grande"}},
		{377.26641845703, -67.437118530273, 1001.5078125, int= 10, dim = 1, items={"Hamburguesa", "Hamburguesa Chica", "Hamburguesa Grande"}},
		{377.26641845703, -67.437118530273, 1001.5078125, int= 10, dim = 0, items={"Hamburguesa", "Hamburguesa Chica", "Hamburguesa Grande"}},
	},
	["Cluckin' Bell"] = {
		{369.76181030273, -6.0199885368347, 1001.8588867188, int= 9, dim = 0, items={"Pata de Pollo", "Hamb. de Pollo", "Pollo Asado"}},
	},
	["Pizza"] = {
		{375.72564697266, -118.80428314209, 1001.4995117188, int= 5, dim = 0, items={"Pizzeta", "Pizza Chica", "Pizza Grande"}},
		{375.72564697266, -118.80428314209, 1001.4995117188, int= 5, dim = 1, items={"Pizzeta", "Pizza Chica", "Pizza Grande"}},
	}
}