-- shared.lua
ArmasTable = {
    {22, "Pistola 9mm", 1000, "Pistola + 17 balas", 17},
    {24, "Desert Eagle .44", 3000, "Pistola + 7 balas", 7},
    {25, "Escopeta Remington", 4000, "Escopeta + 7 balas", 7},
    {33, "Rifle de Caza", 7950, "Rifle + 10 balas", 10},
    {29, "Subfusil MP5", 8150, "Subfusil + 30 balas", 30},
    {31, "Fusil M4A1", 25150, "Fusil + 30 balas", 30},
    {0, "Chaleco", 250, "+50 de chaleco antibalas", 50},
}

ammunations = {
    {nombre = "Ammu-Nation Willowfieldx", x = 2297.431640625, y = 32.900390625, z = 1001.515625, int = 1, dim = 0},
    {nombre = "Ammu-Nation Willowfields", x = 290.4345703125, y = -38.3330078125, z = 1001.515625, int = 1, dim = 0},
    {nombre = "Ammu-Nation Fea", x = 287.4287109375, y = -33.3330078125, z = 1001.515625, int = 1, dim = 0}

}