local MarkersColors = {
{ID=1, Posiciones={2063.388671875, -1831.4580078125, 13.226556777954}, rot={-0, 0, 184.45260620117}, textoMarker ="#FFFF00Modificación de vehículo", int = 0, dim = 0},--{ID=2, Posiciones={1643.5703125, -1516.134765625, 13.247010231018}, rot={-0, 0, 184.45260620117}, textoMarker ="#FFFF00Modificación de vehículo", int = 0, dim = 0},
}

function getMarkersColors()
	return MarkersColors
end