local MarkerRepairs = {
{Posiciones={2081.3422851563, -1804.6514892578, 13.3828125}, textoMarker="#FFFF00Reparación de Coches\n#FFFFFFusa #1B644A/repararvehiculo", int = 0, dim = 0},{Posiciones={1643.5703125, -1516.134765625, 13.247010231018}, textoMarker="#FFFF00Reparación de Coches\n#FFFFFFusa #1B644A/repararvehiculo", int = 0, dim = 0},
}

function getMarkerRepairs()
	return MarkerRepairs
end