----------------------------------------->>
-- GTI: Grand Theft International
-- Author: JT Pennington (JTPenn)
-- Date: 07 Mar 2015
-- Resource: GTIrentals/weapons_table.slua
-- Version: 1.0
----------------------------------------->>

function weaponsTable()	return weapons end

weapons = {
	{id=6,	ammo=1, 	pos={2458.8251953125, -292.43222045898, 26.953544616699-1},			res={"Minero"}},	-- Shovel
}