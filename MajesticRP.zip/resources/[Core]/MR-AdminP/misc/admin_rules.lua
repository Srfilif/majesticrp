adminRules = [[Reglas:

1.- Siempre respetar todas las reglas del server
2.- No usar el panel para beneficio propio ni de tus amigos
3.- Siempre tratar a todos con respeto (no bardo)
4.- Siempre acatar ordenes de administradores de mas nivel
5.- No molestar a los administradores de mas nivel
6.- Siempre usar el tag [PoP] en el nombre

Niveles administrativos:

New Staff:

- Atender todo tipo de dudas de los jugadores
- Mantener el orden en todo momento dentro del servidor
- Desbuguear Jugadores

(Este nivel es considerado una prueba de no mas de 30 dias)

Trained Staff:

- Todo lo del anterior nivel
- Atender castigos del foro
- Reconectar jugadores

Trusted Staff:

- Todo lo de anterior nivel
- Kickear jugadores
- Modificar tiempo de los castigos

High Staff:

- Todo lo del anterior nivel
- Mantener desbugeado el servidor
- Creador de nuevos scripts
- Desbanear jugadores
- Encargado de las pruebas administrativas

Head Staff

- Todo lo del anterior nivel
- Creacion de nuevos scripts
- Eliminacion de cuentas
- Mantenimiendo del servidor y del foro
- Editar datos internos del servidor
- Encargado de las integraciones administrativas]]