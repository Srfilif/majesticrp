# Sistema de grupos para servidores de MTA

Este sistema de grupos cuenta con muchas caracteristicas tales como:
**
* Sistemas de invitaciones
* Sistema de Alianzas
* Sistema de rangos
* Personalizacion del chat grupal e iconos
* Cambiar el nombre de grupo
* Sistema de logs
* Poder eliminar el grupo
* Panel para administradores ( se abre con /cgsp )
* Registro de la ultima conexion de cada miembro**