system_configs = 
{
	delete_stop = false,
	slots 		= 100,
	default_info = [[ Hola, Aqui debes colocar la informacion de tu grupo ]],
	default_color1 = "#00ff00",
	default_color2 = "#ffffff",
	GUI_co_effect = false
}
