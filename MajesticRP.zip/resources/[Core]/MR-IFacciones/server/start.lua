addEventHandler("onResourceStart",getResourceRootElement( getThisResource() ),
function (  )
	setTimer( function()
		desarrollado_by(  );
		asignar_team(  );
		createPlayerBlips(  );
	end, 1000, 1 )
end)