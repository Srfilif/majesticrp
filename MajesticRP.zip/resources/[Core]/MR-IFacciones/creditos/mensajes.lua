function desarrollado_by(  )
	outputServerLog( "Sistema de Facciones Ilegales Cargado con exito" )
	outputDebugString( "Sistema de Facciones Ilegales Cargado con exito" )
end